﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Module
    {
        public string Name { get; set; }
        public int Credits { get; set; }
        public int ClassHoursPerWeek { get; set; }
        public int SelfStudyHoursPerWeek { get; set; }
        public int HoursWorked { get; set; }
        public int HoursRemaining { get; set; }
        public Module(string name, int credits, int classHoursPerWeek ,int numberOfWeeks)
        {
            Name = name;
            Credits = credits;
            ClassHoursPerWeek = classHoursPerWeek;
            SelfStudyHoursPerWeek = (credits * 10) / (numberOfWeeks - classHoursPerWeek);
            HoursWorked = 0;
            HoursRemaining = SelfStudyHoursPerWeek;
        }
    }
    public class Semester
    {
        public DateTime StartDate { get; set; }
        public int NumberOfWeeks { get; set; }
        public List<Module> Modules { get; set; }
        public Semester(DateTime startDate, int numberOfWeeks)
        {
            StartDate = startDate;
            NumberOfWeeks = numberOfWeeks;
            Modules = new List<Module>();
        }
        public void AddModule(Module module)
        {
            Modules.Add(module);
        }
        public void CalculateSelfStudyHoursPerWeek()
        {
            foreach (Module module in Modules)
            {
                module.SelfStudyHoursPerWeek = (module.Credits * 10) / (NumberOfWeeks - module.ClassHoursPerWeek);
            }
        }
        public void CalculateHoursRemaining()
        {
            foreach (Module module in Modules)
            {
                module.HoursRemaining = module.SelfStudyHoursPerWeek - module.HoursWorked;
            }
        }
    }
    public class Program
    {
        public static void Main(string[] args)
        {
            // Create a new semester.
            Semester semester = new Semester(new DateTime(2023, 1, 1), 15);
            // Add some modules to the semester.
            semester.AddModule(new Module("Programming 1", 6, 3, semester.NumberOfWeeks));
            semester.AddModule(new Module("Data Structures and Algorithms", 6, 3,semester.NumberOfWeeks));
            semester.AddModule(new Module("Discrete Mathematics", 3, 2, semester.NumberOfWeeks));
            // Calculate the self-study hours per week for each module.
            semester.CalculateSelfStudyHoursPerWeek();
            // Calculate the hours remaining for each module.
            semester.CalculateHoursRemaining();
            // Print the semester details.
            Console.WriteLine($"Semester start date: {semester.StartDate}");
            Console.WriteLine($"Number of weeks: {semester.NumberOfWeeks}");
            Console.WriteLine("Modules:");
            foreach (Module module in semester.Modules)
            {
                Console.WriteLine($"- {module.Name} ({module.Credits} credits, {module.ClassHoursPerWeek} class hours per week, {module.SelfStudyHoursPerWeek} self-study hours per week, {module.HoursWorked} hours worked, {module.HoursRemaining} hours remaining)");
            }
        }
    }
}