﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace TimeManagementApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Module> Modules { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            Modules = new ObservableCollection<Module>();
            modulesListView.ItemsSource = Modules;
        }
        public class Module
        {
            public string Code { get; }
            public string Name { get; }
            public int Credits { get; }
            public int ClassHours { get; }
            public int SelfStudyHours { get; }

            public Module(string code, string name, int credits, int classHours, int selfStudyHours)
            {
                Code = code;
                Name = name;
                Credits = credits;
                ClassHours = classHours;
                SelfStudyHours = selfStudyHours;
            }
        }
        private void AddModule_Click(object sender, RoutedEventArgs e)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(moduleCodeTextBox.Text) || string.IsNullOrWhiteSpace(moduleNameTextBox.Text)
                || string.IsNullOrWhiteSpace(creditsTextBox.Text) || string.IsNullOrWhiteSpace(classHoursTextBox.Text))
            {
                MessageBox.Show("Please fill in all module details.");
                return;
            }

            // Parse input
            string code = moduleCodeTextBox.Text;
            string name = moduleNameTextBox.Text;
            int credits = int.Parse(creditsTextBox.Text);
            int classHours = int.Parse(classHoursTextBox.Text);

            // Calculate self-study hours
            if (!int.TryParse(weeksTextBox.Text, out int weeks) || !DateTime.TryParse(startDatePicker.Text, out DateTime startDate))
            {
                MessageBox.Show("Please enter valid semester parameters.");
                return;
            }

            int selfStudyHours = (credits * 10) / (weeks - classHours);

            // Create and add the module
            Module module = new Module(code, name, credits, classHours, selfStudyHours);
            Modules.Add(module);
        }
        private void DeleteModule_Click(object sender, RoutedEventArgs e)
        {
            if (modulesListView.SelectedItems.Count > 0)
            {
                // Remove the selected module(s)
                foreach (var selectedModule in modulesListView.SelectedItems.Cast<Module>().ToList())
                {
                    Modules.Remove(selectedModule);
                }
            }
            else
            {
                MessageBox.Show("Please select a module to delete.");
            }
        }

        private void ResetValues_Click(object sender, RoutedEventArgs e)
        {
            // Clear input fields
            moduleCodeTextBox.Text = "Module Code";
            moduleNameTextBox.Text = "Module Name";
            creditsTextBox.Text = "Credits";
            classHoursTextBox.Text = "Class Hours per Week";

            // Clear the modules list
            Modules.Clear();

            // Clear semester parameters
            weeksTextBox.Text = "";
            startDatePicker.SelectedDate = null;
        }
    }
}
